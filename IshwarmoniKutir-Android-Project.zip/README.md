# ঈশ্বরমনি কুঠির,সাহা বাড়ি — Android APK project

এই Android Studio project আপনার live website `https://ishwar-moni-kutir.vercel.app/` অ্যাপের মধ্যে দেখায়। ওয়েবসাইটের ডিজাইন/কনটেন্ট লাইভ সাইট থেকেই আসবে; ইন্টারনেট প্রয়োজন।

## APK তৈরি
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio-তে Open করে এই project folder বাছুন।
3. Gradle Sync শেষ করুন; SDK চাইলে ইনস্টল করুন।
4. Build > Build APK(s) চাপুন। APK `app/build/outputs/apk/debug/app-debug.apk`-এ থাকবে।

এটি Android Studio source project, compiled APK নয়। APK তৈরি করতে Android SDK/Gradle build environment প্রয়োজন। Android Studio-র অফিসিয়াল নির্দেশনা: https://developer.android.com/build/build-for-release
